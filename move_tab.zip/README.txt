Made by Zhi Bin Wu

Description: Move tabs with a keyboard shortcut instead of dragging them

Icons made by Google from http://www.freepik.com